package com.example.tp2;

/**
 * Created by julio on 01/11/17.
 */

public class listItem {
    private String head;
    private String desc;

    public listItem(String head, String desc) {
        this.head = head;
        this.desc = desc;
    }

    public String getHead() {
        return head;
    }

    public String getDesc() {
        return desc;
    }
}
